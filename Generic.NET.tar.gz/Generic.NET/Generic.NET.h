// GenericNET.h

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

using namespace System;

namespace GenericNET
{
	public __gc class Class1
	{
	public:
		Class1()
		{
		}
	
	private:
		
	};
}