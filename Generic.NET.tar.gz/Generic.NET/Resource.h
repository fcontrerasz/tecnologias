//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Generic.NET.rc
//
#define IDI_ICON1                       114
#define IDD_DIALOG1                     116
#define IDR_MENU1                       117
#define IDD_DIALOG2                     118
#define ID_APP_OPEN                     32775
#define ID_APP_SUSPEND                  32776
#define ID_MENU_TEST                    32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        119
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           209
#endif
#endif
