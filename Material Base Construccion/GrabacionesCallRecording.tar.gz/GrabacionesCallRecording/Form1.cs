using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace GrabacionesCallRecording
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Data.SqlClient.SqlDataAdapter sqlDataAdapter1;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		private System.Data.SqlClient.SqlConnection sqlConnection1;
		private GrabacionesCallRecording.Dataset1 dataset11;
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Button button2;
		private System.Data.SqlClient.SqlConnection sqlConnection2;
		private System.Data.SqlClient.SqlCommand sqlCommand1;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.GroupBox Par�metros;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.ProgressBar progressBar1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			folderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.Desktop;

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.dataset11 = new GrabacionesCallRecording.Dataset1();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.Par�metros = new System.Windows.Forms.GroupBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.button4 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
			this.button3 = new System.Windows.Forms.Button();
			this.sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			this.sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.progressBar1 = new System.Windows.Forms.ProgressBar();
			((System.ComponentModel.ISupportInitialize)(this.dataset11)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.Par�metros.SuspendLayout();
			this.SuspendLayout();
			// 
			// sqlDataAdapter1
			// 
			this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "[RecordingTelescript]";
			this.sqlSelectCommand1.CommandType = System.Data.CommandType.StoredProcedure;
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			this.sqlSelectCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlSelectCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@project", System.Data.SqlDbType.VarChar, 8));
			this.sqlSelectCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fecha", System.Data.SqlDbType.VarChar, 20));
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "packet size=4096;user id=sa;data source=sagan;persist security info=True;initial " +
				"catalog=CallRecording;password=ta0571z8;Connect Timeout=120";
			// 
			// dataset11
			// 
			this.dataset11.DataSetName = "Dataset1";
			this.dataset11.Locale = new System.Globalization.CultureInfo("en-US");
			// 
			// dataGrid1
			// 
			this.dataGrid1.AlternatingBackColor = System.Drawing.Color.LightGray;
			this.dataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dataGrid1.BackColor = System.Drawing.Color.DarkGray;
			this.dataGrid1.CaptionBackColor = System.Drawing.Color.White;
			this.dataGrid1.CaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
			this.dataGrid1.CaptionForeColor = System.Drawing.Color.Navy;
			this.dataGrid1.DataMember = "";
			this.dataGrid1.DataSource = this.dataset11._Table;
			this.dataGrid1.ForeColor = System.Drawing.Color.Black;
			this.dataGrid1.GridLineColor = System.Drawing.Color.Black;
			this.dataGrid1.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
			this.dataGrid1.HeaderBackColor = System.Drawing.Color.Silver;
			this.dataGrid1.HeaderForeColor = System.Drawing.Color.Black;
			this.dataGrid1.LinkColor = System.Drawing.Color.Navy;
			this.dataGrid1.Location = new System.Drawing.Point(8, 8);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.ParentRowsBackColor = System.Drawing.Color.White;
			this.dataGrid1.ParentRowsForeColor = System.Drawing.Color.Black;
			this.dataGrid1.PreferredColumnWidth = 100;
			this.dataGrid1.SelectionBackColor = System.Drawing.Color.Navy;
			this.dataGrid1.SelectionForeColor = System.Drawing.Color.White;
			this.dataGrid1.Size = new System.Drawing.Size(800, 160);
			this.dataGrid1.TabIndex = 0;
			this.dataGrid1.Navigate += new System.Windows.Forms.NavigateEventHandler(this.dataGrid1_Navigate);
			// 
			// Par�metros
			// 
			this.Par�metros.Controls.Add(this.textBox3);
			this.Par�metros.Controls.Add(this.checkBox1);
			this.Par�metros.Controls.Add(this.button4);
			this.Par�metros.Controls.Add(this.label3);
			this.Par�metros.Controls.Add(this.textBox2);
			this.Par�metros.Controls.Add(this.button2);
			this.Par�metros.Controls.Add(this.button1);
			this.Par�metros.Controls.Add(this.dateTimePicker1);
			this.Par�metros.Controls.Add(this.label2);
			this.Par�metros.Controls.Add(this.label1);
			this.Par�metros.Controls.Add(this.textBox1);
			this.Par�metros.Location = new System.Drawing.Point(8, 176);
			this.Par�metros.Name = "Par�metros";
			this.Par�metros.Size = new System.Drawing.Size(800, 152);
			this.Par�metros.TabIndex = 1;
			this.Par�metros.TabStop = false;
			this.Par�metros.Text = "Par�metros";
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(440, 16);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(176, 20);
			this.textBox3.TabIndex = 13;
			this.textBox3.Text = "";
			this.textBox3.Visible = false;
			// 
			// checkBox1
			// 
			this.checkBox1.Location = new System.Drawing.Point(168, 8);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(264, 32);
			this.checkBox1.TabIndex = 12;
			this.checkBox1.Text = "Usar Procedimiento para base de datos y tabla con distinto nombre";
			this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(696, 16);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(96, 40);
			this.button4.TabIndex = 10;
			this.button4.Text = "RESET";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(440, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(144, 16);
			this.label3.TabIndex = 9;
			// 
			// textBox2
			// 
			this.textBox2.Enabled = false;
			this.textBox2.Location = new System.Drawing.Point(168, 120);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(248, 20);
			this.textBox2.TabIndex = 8;
			this.textBox2.Text = "C:\\";
			// 
			// button2
			// 
			this.button2.Enabled = false;
			this.button2.Location = new System.Drawing.Point(440, 120);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(168, 24);
			this.button2.TabIndex = 7;
			this.button2.Text = "Elegir Directorio Destino";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(440, 72);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(112, 24);
			this.button1.TabIndex = 4;
			this.button1.Text = "Buscar";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
			this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimePicker1.Location = new System.Drawing.Point(168, 72);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(248, 20);
			this.dateTimePicker1.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(64, 72);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(88, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "Fecha";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(64, 48);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "C�digo Proyecto";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(168, 48);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(248, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "";
			// 
			// button3
			// 
			this.button3.Enabled = false;
			this.button3.Location = new System.Drawing.Point(696, 536);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(112, 48);
			this.button3.TabIndex = 7;
			this.button3.Text = "Guardar";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// sqlConnection2
			// 
			this.sqlConnection2.ConnectionString = "packet size=4096;user id=sa;data source=sagan;persist security info=True;initial " +
				"catalog=I3_IC_2005;password=ta0571z8;Connect Timeout=120";
			// 
			// sqlCommand1
			// 
			this.sqlCommand1.CommandText = "dbo.[GetFilenameByCallID]";
			this.sqlCommand1.CommandType = System.Data.CommandType.StoredProcedure;
			this.sqlCommand1.Connection = this.sqlConnection2;
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@callid", System.Data.SqlDbType.VarChar, 18));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@file", System.Data.SqlDbType.VarChar, 50));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@filename", System.Data.SqlDbType.VarChar, 500, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(8, 368);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(656, 212);
			this.listBox1.TabIndex = 8;
			// 
			// progressBar1
			// 
			this.progressBar1.Cursor = System.Windows.Forms.Cursors.AppStarting;
			this.progressBar1.Location = new System.Drawing.Point(8, 344);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new System.Drawing.Size(656, 16);
			this.progressBar1.TabIndex = 9;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(816, 597);
			this.Controls.Add(this.progressBar1);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.Par�metros);
			this.Controls.Add(this.dataGrid1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "Form1";
			this.Text = "Grabaciones por CallRecording";
			((System.ComponentModel.ISupportInitialize)(this.dataset11)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.Par�metros.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void dataGrid1_Navigate(object sender, System.Windows.Forms.NavigateEventArgs ne)
		{
		
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			try
			{	
				FileInfo t = new FileInfo(textBox2.Text + @"\Grabaciones.xls");
				StreamWriter Tex = t.CreateText();
				Tex.WriteLine("<html><body><style>.number{mso-number-format:Text;}</style><table border='1'>");
				Tex.WriteLine("<tr>");
				Tex.Write("<td>CallID</td>");
				Tex.Write("<td>Quota</td>");
				Tex.Write("<td>Telelink</td>");
				Tex.Write("<td>CallDT</td>");
				Tex.Write("<td>UserID</td>");
				Tex.Write("<td>PHONE1</td>");
				Tex.Write("<td>ResultCode</td>");
				Tex.Write("<td>Grabacion</td>");
				Tex.WriteLine("</tr>");
				for (int i=0;i<dataset11.Tables[0].Rows.Count;i++)
				{
					Tex.WriteLine("<tr>");
					Tex.Write("<td>&nbsp;" + dataset11.Tables[0].Rows[i]["CallId"].ToString() + "</td>");
					Tex.Write("<td>&nbsp;" + dataset11.Tables[0].Rows[i]["Quota"].ToString() + "</td>");
					Tex.Write("<td>" + dataset11.Tables[0].Rows[i]["Telelink"].ToString() + "</td>");
					Tex.Write("<td>" + dataset11.Tables[0].Rows[i]["CallDT"].ToString() + "</td>");
					Tex.Write("<td>" + dataset11.Tables[0].Rows[i]["UserID"].ToString() + "</td>");
					Tex.Write("<td>&nbsp;" + dataset11.Tables[0].Rows[i]["PHONE1"].ToString() + "</td>");
					Tex.Write("<td>" + dataset11.Tables[0].Rows[i]["ResultCode"].ToString() + "</td>");
					Tex.Write("<td><a href='" + dataset11.Tables[0].Rows[i]["Filename"].ToString() + "'>Grabaci�n</a></td>");
					Tex.WriteLine("</tr>");
				}
				Tex.WriteLine("</table></body></html>");
				Tex.Close();

				listBox1.Items.Add("Copiado Archivo Excel ...");
			
				int j = 0;
				int g = 0;

				progressBar1.Minimum = 0;
				progressBar1.Maximum = dataset11.Tables[0].Rows.Count;

				sqlConnection2.Open();
				for(int i=0;i<dataset11.Tables[0].Rows.Count;i++)
				{
					string f =  dataset11.Tables[0].Rows[i]["Filename"].ToString();
					string callid = dataset11.Tables[0].Rows[i]["CallId"].ToString();

					sqlCommand1.Parameters["@callid"].Value = callid;
					sqlCommand1.Parameters["@file"].Value = "%" + f;
					sqlCommand1.ExecuteNonQuery();

					
					string ff = sqlCommand1.Parameters["@filename"].Value.ToString();
					if (ff.Length>0)
					{
						File.Copy(ff, textBox2.Text + "\\" + f,true);
						listBox1.Items.Add("Copiado Archivo de Audio " + ff);
						g++;

					}
					else
					{
						listBox1.Items.Add("No se pudo copiar archivo " + f + " CallID = " + callid);
					}
					progressBar1.Value = j;

					listBox1.Select();
					listBox1.ClearSelected();
					listBox1.SelectedIndex = listBox1.Items.Count - 1; 
					
					j++;
				}

				listBox1.Items.Add("Copiados " + g.ToString() + " Archivos de Audio");
				listBox1.Select();
				listBox1.ClearSelected();
				listBox1.SelectedIndex = listBox1.Items.Count - 1; 

			}
			catch(Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message,"Grabaciones");
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			folderBrowserDialog1.ShowDialog();
			textBox2.Text = folderBrowserDialog1.SelectedPath;
			if (textBox2.Text.Length>0)
			{
				button3.Enabled = true;
			}

		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			try
			{
				
				this.dataset11.Tables[0].Clear();
				if (textBox1.Text.Length>0)
				{
					if (checkBox1.Checked)
					{
						sqlSelectCommand1.CommandText = "[RecordingTelescript2]";
						this.sqlSelectCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@project2", System.Data.SqlDbType.VarChar, 8));
						sqlSelectCommand1.Parameters["@project"].Value = textBox3.Text;
						sqlSelectCommand1.Parameters["@project2"].Value = textBox1.Text;
						
						}
					else
					{
						if (this.sqlSelectCommand1.Parameters.Contains("@project2")) this.sqlSelectCommand1.Parameters.Remove(sqlSelectCommand1.Parameters["@project2"]);
						sqlSelectCommand1.Parameters["@project"].Value = textBox1.Text;
					}
					sqlSelectCommand1.Parameters["@fecha"].Value = dateTimePicker1.Value.Year.ToString() + "-" + dateTimePicker1.Value.Month.ToString() + "-" +  dateTimePicker1.Value.Day.ToString();
					sqlDataAdapter1.Fill(this.dataset11);
					sqlConnection1.Close();
					button2.Enabled = true;
					textBox2.Enabled = true;
					label3.Text = dataset11.Tables[0].Rows.Count.ToString() + " Registros";

				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message + ex.StackTrace, "Error");
			}
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			textBox1.Text = "";
			textBox2.Text = @"C:\";
			button2.Enabled = false;
			textBox2.Enabled = false;
			label3.Text = "";
			button3.Enabled = true;
			listBox1.Items.Clear();
			textBox3.Text = "";
			progressBar1.Value = 0;

		}

		private void checkBox1_CheckedChanged(object sender, System.EventArgs e)
		{
			if (checkBox1.Checked)
				textBox3.Visible = true;
			else
				textBox3.Visible = false;
		}

	}
}
