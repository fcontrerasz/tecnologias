//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Generic.rc
//
#define IDI_ICON1                       4000
#define IDR_MENU1                       4001
#define IDD_DIALOG2                     4002
#define ID_METS                         32771
#define ID_METS_TEST                    32772
#define ID_ACCIONES_TEST                32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        4003
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         4000
#define _APS_NEXT_SYMED_VALUE           4000
#endif
#endif
